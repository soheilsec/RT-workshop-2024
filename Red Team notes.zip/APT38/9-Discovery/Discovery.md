Browser Information Discovery T1217

execute `C:\Users\soheil\Desktop\APT38\8-Credential Access\LaZagne.exe` all

File and directory discovery T1083

```powershell
dir /s c:\ >> c:\users\public\d.txt
```
```powershell
dir /s "c:\Documents and Settings" >> c:\users\public\d.txt
```
```powershell
dir /s "c:\Program Files\" >> c:\users\public\d.txt
```
```powershell
dir "%systemdrive%\Users\*.*" >> c:\users\public\d.txt
```
```powershell
dir "%userprofile%\AppData\Roaming\Microsoft\Windows\Recent\*.*" >> c:\users\public\d.txt
```
```powershell
dir "%userprofile%\Desktop\*.*" >> c:\users\public\d.txt
```
```powershell
tree /F >> c:\users\public\d.txt
```

Network Share discovery T1135

net share

Process Discovery T1057

```powershell
get-wmiObject -class Win32_Process
```
```powershell
wmic process get /format:list
```


Software discovery =>
security software discovery T1518.001
show allprofiles -> `netsh.exe advfirewall  `
firewall dump -> `netsh.exe advfirewall `
show currentprofile -> `netsh.exe advfirewall `
show rule name=all -> `netsh.exe advfirewall firewall`
show state -> `netsh.exe firewall `
show config -> `netsh.exe firewall `
sc query windefend

```c
powershell.exe /c "Get-Process | Where-Object { $_.ProcessName -eq 'Sysmon' }"
```
```c
powershell.exe /c "Get-Service | where-object {$_.DisplayName -like '*sysm*'}"
```
```c
powershell.exe /c "Get-CimInstance Win32_Service -Filter 'Description = ''System Monitor service'''"
```

tasklist.exe
```c
tasklist.exe | findstr /i virus
```
```c
tasklist.exe | findstr /i cb
```
```c
tasklist.exe | findstr /i defender
```
```c
tasklist.exe | findstr /i cylance
```
```c
tasklist.exe | findstr /i mc
```
```c
tasklist.exe | findstr /i "virus cb defender cylance mc"
```
```c
fltmc.exe | findstr.exe 385201
```
```c
get-process | ?{$_.Description -like "*virus*"}
```
```c
get-process | ?{$_.Description -like "*carbonblack*"}
```
```c
get-process | ?{$_.Description -like "*defender*"}
```
```c
get-process | ?{$_.Description -like "*cylance*"}
```
```c
get-process | ?{$_.Description -like "*mc*"}
```
```c
get-process | ?{$_.ProcessName -like "*mc*"}
```
```c
get-process | Where-Object { $_.ProcessName -eq "Sysmon" }
```
```c
wmic.exe /Namespace:\\root\SecurityCenter2 Path AntiVirusProduct Get displayName /Format:List
```
```c
powershell Get-CimInstance -Namespace root/securityCenter2 -classname antivirusproduct
```
```c
powershell Get-WmiObject -Namespace root\securitycenter2 -Class antivirusproduct
```

`Get-Service WinDefend` ->  check the service state of Windows Defender
`Get-MpComputerStatus ` -> provides the current status of security solution elements, including Anti-Spyware, Antivirus, LoavProtection, Real-time protection, etc
`Get-MpThreat ` -> threats details that have been detected using MS Defender

```c
Get-NetFirewallProfile | Format-Table Name, Enabled
```
```c
Get-NetFirewallSetting
```
```c
Get-NetFirewallRule | select DisplayName, Enabled, Description
```



System information Discovery T1082
```c
systeminfo
```
```c
reg query HKLM\SYSTEM\CurrentControlSet\Services\Disk\Enum
```

hostname
```c
REG QUERY HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography /v MachineGuid
```


System network connection discovery T1049

```c
netstat
```
```c
net use
```
```c
net sessions
```

```c
Get-NetTCPConnection
```

System Owner/user discovery T1033

```c
cmd.exe /C whoami
```
```c
wmic useraccount get /ALL
```
```c
quser /SERVER:"#{computer_name}"
```
```c
quser
```
```c
qwinsta.exe /server:#{computer_name}
```
```c
qwinsta.exe
for /F "tokens=1,2" %i in ('qwinsta /server:#{computer_name} ^| findstr "Active Disc"') do @echo %i | find /v "#" | find /v "console" || echo %j > computers.txt
@FOR /F %n in (computers.txt) DO @FOR /F "tokens=1,2" %i in ('qwinsta /server:%n ^| findstr "Active Disc"') do @echo %i | find /v "#" | find /v "console" || echo %j > usernames.txt
```

```cmd
ipconfig

ping

arp

net

whoami

query session
```
