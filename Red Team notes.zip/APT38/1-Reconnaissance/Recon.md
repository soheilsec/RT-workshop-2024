

phase 0
```link
https://x.com/Cryptolaemus1

https://x.com/malware_traffic

https://x.com/pr0xylife

https://x.com/cyb3rops
```
