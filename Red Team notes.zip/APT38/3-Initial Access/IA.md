Drive By compromise T1189

Scenario:

HTML smuggeling auto download shortcut(PDF) run cobaltstrike payload

Phishing => SpearPhishing Attachment T1566.001

word macro

cobalt strike + word
