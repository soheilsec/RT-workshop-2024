Clipboard Data T1115

clipboard

Data from local system T1005


Input Capture => 

Keylogging T1056.001