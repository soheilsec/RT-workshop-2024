Data Destruction T1485


Data Encrypted for impact T1486


Data Manipulation =>

Runtime data manipulation T1565.003


Stored Data manipulation T1565.001


Transmitted Data manipulation T1565.002


Disk Wipe =>

Disk Structure wipe T1561.002


System shutdown/ Reboot T1529