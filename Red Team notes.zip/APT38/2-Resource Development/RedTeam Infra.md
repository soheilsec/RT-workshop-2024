T1588.002

Obtain Capabilities => Tool


```txt
https://github.com/bluscreenofjeff/Red-Team-Infrastructure-Wiki
```