Create or modify system process =>

Windows Service T1543.003



Scheduled Task/job =>

Cron T1053.003

Scheduled Task T1053.005


