
$hh = "$(pwd)\..\hh\hh.exe"
$hhc = "$(pwd)\..\hh\hhc.exe"

$projPath = "$(pwd)\src\project.hpp"

Write-Host "`n[+] Step 1: Compiling dodgy .CHM..." -ForegroundColor green
& "$hhc" "$projPath"

mv "$(pwd)\src\project.chm" spawn-calc.chm -Force
